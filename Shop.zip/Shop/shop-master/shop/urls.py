from django.contrib import admin
from django.urls import path
from shop import views

from shop.views import product_list

urlpatterns = [
    path('', product_list, name='products'),
    path('/home', views.home, name='home'),
    path('', views.product_list, name='product_list'),
    path('<int:pk>/', views.product_detail, name='product_detail'),
]
